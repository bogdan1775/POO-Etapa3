package app;

public final class Notification {
    private String description;
    private String name;

    public String getDescription() {
        return description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(final String title) {
        this.name = title;
    }

}
